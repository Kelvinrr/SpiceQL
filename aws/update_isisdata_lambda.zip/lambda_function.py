import json
import pyspiceql

def lambda_handler(event, context):
    
    # TODO implement
    print(f"event: ", event)
    print(f"context: ", context)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

